import java.awt.Image;

import javax.swing.ImageIcon;

public class BodyPart extends GameObject {

	public BodyPart(int x, int y) {
		super(x, y, (new ImageIcon("Body.png")));

	}

	public BodyPart(ImageIcon image) {
		super(30, 180, image);

	}

}