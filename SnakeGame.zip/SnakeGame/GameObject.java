import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public abstract class GameObject {
	private int x;
	private int y;
	private JLabel image;

	//method that initializes a game object and gives it a x and y position within the JPanel
	public GameObject(int x, int y, ImageIcon image) {
		setX(x);
		setY(y);
		this.image = new JLabel(image);
		this.image.setBounds(x, y, 30, 30);

	}

	//getter for x position
	public int getX() {
		return x;

	}

	//setter for x position
	public void setX(int x) {
		this.x = x;

	}

	//getter for y position
	public int getY() {
		return y;

	}

	//setter for y position
	public void setY (int y)
	{
			this.y = y;
			
		
		
	}

	//getter for images
	public JLabel getImage() {
		return image;
	}

	//setter for image position
	public void setImagePosition() {
		image.setBounds(x, y, 30, 30);
	}

}// end GameObject class