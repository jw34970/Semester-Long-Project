/******************************************
 * @description Semester Long Project
 *
 * Programmer (Jared Whetman)
 * 
 * @version (December 6, 2019)
 *****************************************/
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JSplitPane;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GameDriver extends JFrame implements ActionListener, KeyListener {
	
	//instance variables
	private Snake snake;
	private Apple apple;
	private Wall[] walls;
	private JPanel panel;
	private JTextArea score;

	
	//game driver method that creates the JFrame and JPanel and game objects, sets the background to white
	//sets the dimensions of the JPanel. When the X button in the upper right hand corner is clicked the Program terminates.
	public GameDriver() {
		getContentPane().setLayout(null);
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 360, 360);
		getContentPane().add(panel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//creates objects for snake, apple, and walls to be used in the game
		snake = new Snake();
		apple = new Apple();
		walls = new Wall[44];

		
		//for loop that prints walls around the border of the JPanel. The walls are created
		//within the the specified borders of the JPanel to create the game boundaries.
		int counter = 0;
		for (int i = 0; i < 360; i += 30) {
			for (int a = 0; a < 360; a += 30) {

				if (i == 0 || i == 330) {
					walls[counter] = new Wall(a, i);
					counter++;
				} else if (a == 0 || a == 330) {
					walls[counter] = new Wall(a, i);
					counter++;
				}

			}

		}

		panel.setLayout(null);
		setSize(new Dimension(570, 399));
		panel.add(snake.getBodyParts()[0].getImage());
		
		//creates a text area to keep track of the score
		score = new JTextArea();
		score.setText("Score: 0");
		score.setBounds(150, 5, 60, 20);
		panel.add(score);

		// creates a start button with a listener for when the mouse button is clicked. 
		//when the the start button is clicked the game runs
		JButton btnNewButton = new JButton("Start");
		btnNewButton.setFocusable(false);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				start();
			}
		});
		btnNewButton.setBounds(370, 8, 174, 23);
		getContentPane().add(btnNewButton);

		// creates a text area that displays the game description within the JPanel
		JTextArea txtrWelcomeToThe = new JTextArea();
		txtrWelcomeToThe.setFont(new Font("Monospaced", Font.PLAIN, 12));
		txtrWelcomeToThe.setWrapStyleWord(true);
		txtrWelcomeToThe.setLineWrap(true);
		txtrWelcomeToThe.setText(
				"Welcome to the Snake Game! The object of this game is to eat as many apples as possible without running into walls and your snake body. Each time you eat an apple the snake grows one body part. You can only make 90 degree turns. Use the UP, DOWN, LEFT, RIGHT arrow keys to direct the snake. Click the Start button to begin a game or load a new game. Have Fun!");
		txtrWelcomeToThe.setBounds(370, 42, 174, 307);
		getContentPane().add(txtrWelcomeToThe);
		for (Wall w : walls) {
			panel.add(w.getImage());
		}

		//sets the JFrame to be visible
		setVisible(true);

		//variables for eatApple and BodyPart
		boolean eatApple = false;
		BodyPart newPart = null;
		

		//while loop to run game
		while (true) {
			repaint();
			score.setText("Score: "+ snake.getLength());
			
			if (snake.isAlive())
				snake.move();
			else {
				JTextArea dead = new JTextArea();
				dead.setText("Click Start");
				dead.setBounds(100, 160, 160, 40);
				dead.setFont(new Font("Monospaced", Font.PLAIN, 24));
				panel.add(dead);
			}

			if (newPart != null) {
				snake.addBodyPart(newPart);
				panel.add(newPart.getImage());
				newPart = null;
				apple.moveApple();

			}

			if (collisionDectection()) {
				newPart = snake.newBodyPart();

			}
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}// end

	
	//method to detect when the head of the snake run into a wall or if the snake head
	//runs into an apple. If the snake runs into a wall the boolean variable is changed to false and the game quits
	//if the snake head runs into an apple the boolean value remains true and the game continues. A new apple is placed
	//within the JPanel
	public boolean collisionDectection() {

		boolean eatApple = false;
		BodyPart bodyparts[] = snake.getBodyParts();
		int headX = bodyparts[0].getX();
		int headY = bodyparts[0].getY();

		if (headX == 0 || headX == 330 || headY == 0 || headY == 330) {
			snake.setAlive(false);
			
		}

		else if (headX == apple.getX() && headY == apple.getY()) {

			eatApple = true;
			

		}

		else
			for (int i = 1; i <= snake.getLength(); i++) {
				int bodyX = bodyparts[i].getX();
				int bodyY = bodyparts[i].getY();

				if (bodyX == headX && bodyY == headY) {
					snake.setAlive(false);
					
				}

			}

		return eatApple;

	}

	//A game start method that initializes the snake head, walls, and and places the snake head at a starting position on the map
	//the snake boolean isAlive value is set to true.
	public void start() {
		Component[] components = panel.getComponents();
		for (Component c: components) {
			if (c instanceof JLabel || c instanceof JTextArea) {
				panel.remove(c);
			}
		}
		BodyPart [] bp = snake.getBodyParts();
		snake.setLength(0);
		for (int i = 1; i < bp.length; i++) {
			bp[i] = null;
		}
		Head head = (Head)bp[0];
		head.setX(30);
		head.setY(180);
		head.setDirection(0);
		panel.add(score);
		apple.moveApple();
		panel.add(snake.getBodyParts()[0].getImage());
		panel.add(apple.getImage());
		for (Wall w : walls) {
			panel.add(w.getImage());
		}
		
		snake.setAlive(true);
		
	}

	
	//main method that calls the GameDriver class and runs the game. The movement keys up, down, left, and right 
	//are mapped to move the snake from the setDirection method in class snake.
	public static void main(String[] args) {
		new GameDriver();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		int key = e.getKeyCode();
		Head head = snake.getHead();
		int direction = head.getDirection();

		if ((key == KeyEvent.VK_LEFT) && (direction != 0)) {
			head.setDirection(2);
		}

		if ((key == KeyEvent.VK_RIGHT) && (direction != 2)) {
			head.setDirection(0);
		}

		if ((key == KeyEvent.VK_UP) && (direction != 1)) {
			head.setDirection(3);
		}

		if ((key == KeyEvent.VK_DOWN) && (direction != 3)) {
			head.setDirection(1);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}
}// end GameDriver class