import javax.swing.ImageIcon;

public class Apple extends GameObject
{
	//constructor that reads in the apple image from a super method
	public Apple()
	{
		super ((int)180,180, (new ImageIcon("Apple.png")));

		
		
		
		
	}
	
	//method that moves the apples position to a random location
	public void moveApple()
	{
		this.setX((int)(Math.random ()*10 + 1)*30);
		this.setY((int)(Math.random ()*10 + 1)*30);	
		this.setImagePosition();
		
	}
	
	 




}//end apple class