public class Snake  
{
	private boolean isAlive;
	private BodyPart [] bodyparts;
	private int length;
	private Head head;
	
	
	//no argument constructor for the Snake object
	public Snake()
	{
		isAlive = false;
		bodyparts = new BodyPart [100];
		
		head = new Head();
		
		bodyparts [0] = head;
		length = 0;
		
		
	}
	
	//boolean value that is set to isAlive
	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	//adds a bodypart to the snake by creating a new body part to the snake body
	public BodyPart newBodyPart()
	{
		BodyPart bodypart = new BodyPart(bodyparts[length].getX(), bodyparts[length].getY());
		
		return bodypart;
		
	}
	
	
	public void addBodyPart(BodyPart newPart)
	{
		length++;
		bodyparts[length] = newPart;
	}
	
	//move the the snake
	public void move()
	{
		for (int i = length; i > 0; i--)
		{
			bodyparts[i].setX(bodyparts[i-1].getX());
			bodyparts[i].setY(bodyparts[i-1].getY());
			bodyparts[i].setImagePosition();
		}
		
		//switch statement that changes the direction of the snake based on each case. 
		//The move methods are called from the head class
		switch (head.getDirection())
		{
				case 0:
					head.moveRight();
					break;
				case 1:
					head.moveDown();
					break;
				case 2:
					head.moveLeft();
					break;
				case 3:
					head.moveUp();
					break;
				default:
					break;
		}
		
	}
	
	
	
	
	//getter for the snakes length
	public int getLength() {
		return length;
	}

	//setter for the snakes length
	public void setLength(int length) {
		this.length = length;
	}

	//getter for the bodypart
	public BodyPart[] getBodyParts()
	{
		return bodyparts;
		
	}

	//getter for head
	public Head getHead() {
		return head;
	}

	//setter for head
	public void setHead(Head head) {
		this.head = head;
	}
	
	

}//end Snake class
