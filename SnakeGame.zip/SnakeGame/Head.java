import javax.swing.ImageIcon;

public class Head extends BodyPart {
	private int direction;

	//constructor that reads in the Head image
	public Head() {

		super(new ImageIcon("Head.png"));

	}

	//setter for the direction of the snake head
	public void setDirection(int direction) {
		this.direction = direction;

	}

	//getter for the snake head direction
	public int getDirection() {
		return direction;

	}

	//method that turns the position of the snake to the left by decreasing the x value
	public void moveLeft() {
		this.setX(this.getX() - 30);
		this.setImagePosition();

	}

	//method that turns the position of the snake to the right by increasing the x value
	public void moveRight() {
		this.setX(this.getX() + 30);
		this.setImagePosition();

	}

	//method that turns the position of the snake up by decreasing the y value
	public void moveUp() {

		this.setY(this.getY() - 30);
		this.setImagePosition();

	}

	//method that turns the position of the snake up by increasing the y value
	public void moveDown() {
		this.setY(this.getY() + 30);
		this.setImagePosition();

	}

}//end Head class
