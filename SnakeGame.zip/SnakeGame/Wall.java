import javax.swing.ImageIcon;

public class Wall extends GameObject
{
	//constructor that reads in the Wall image using a super method
	public Wall(int x, int y)
	{
		super (x,y,(new ImageIcon("Wall.png")));
	}
	
	
}//end Wall class
